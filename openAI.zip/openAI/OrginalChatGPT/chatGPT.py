
# API-Key:   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

import openai
import csv

openai.api_key = "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"

def askChatGPT(messages):
    MODEL = "gpt-3.5-turbo"
    response = openai.ChatCompletion.create(
        model=MODEL,
        messages = messages,
        temperature=1)
    return response['choices'][0]['message']['content']

def EnglishTeacher():
    messages = [{"role": "system","content":"你是一个英语口语老师。我会用英语和你说话，你也会用英语回答我，练习我的口语。我希望你的回复保持简洁，限制在100字以内。我希望你能严格纠正我的语法错误、拼写错误和事实错误。我想让你在回答时继续问我一个问题。现在让我们开始练习，你可以先问我一个问题。记住，我要你严格纠正我的语法错误、拼写错误和事实错误。"}]
    print('你面前的是你的英语口语老师，你们将通过这个程序练习英语\n当你输入 quit 时，将终止程序\n')
    return messages


def save_dict_list_to_csv(dict_list, filename):
    """
    将字典列表保存为CSV文件
    dict_list: 字典列表
    filename: 文件名
    """
    with open(filename, mode='w', newline='') as f:
        fieldnames = list(dict_list[0].keys())
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for my_dict in dict_list:
            writer.writerow(my_dict)

def load_dict_list_from_csv(filename):
    """
    从CSV文件中恢复字典列表
    filename: 文件名
    return: 字典列表
    """
    dict_list = []
    with open(filename, mode='r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            dict_list.append(row)
    return dict_list

def main():
    # messages = [{"role": "system","content":""}]
    # while 1:
    #     try:
    #         text = input('You：')
    #         if text == 'quit':
    #             break
    #
    #         d = {"role":"user","content":text}
    #         messages.append(d)
    #
    #         text = askChatGPT(messages)
    #         d = {"role":"assistant","content":text}
    #         print('Teacher：'+text+'\n')
    #         messages.append(d)
    #     except:
    #         messages.pop()
    #         print('failed...\n')
    # save_dict_list_to_csv(messages, "message.csv")
    dict_ = load_dict_list_from_csv("message.csv")
    print(dict_)




main()
