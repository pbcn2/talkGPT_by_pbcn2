import time
import openai


class AudioToText:
    def __init__(self, api_key):
        self.api_key = api_key
        openai.api_key = api_key
        self.MODEL = "gpt-3.5-turbo"

    @staticmethod
    def transcribe(file_name):
        audio_file = open(file_name, "rb")
        try:
            audio_file.read()  # 尝试读取文件内容
            print("File is open...")  # 如果能够读取，则文件已经被打开
        except FileNotFoundError:
            print("File is not open.")  # 如果文件未找到，则文件未被打开
            return 0
        audio_file.seek(0)  # f.read()读取文件指针会跑到文件的末端，如果再一次读取，读取的将是空格，所以要重定向文件指针
        transcript = openai.Audio.transcribe("whisper-1", audio_file)
        print("Successfully converted...")
        time.sleep(1)
        return transcript.text

    @staticmethod
    def write_output(text):
        file = open("result.txt", "w")
        # 写入一段文字
        file.write(text)
        # 关闭文件
        file.close()

    def main(self, file_name, prompt):
        original_text = self.transcribe(file_name)
        if original_text == 0:
            print("fail to convert")
        self.write_output(original_text)


if __name__ == '__main__':
    api_key = "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"
    text_summarizer = AudioToText(api_key)
    file_name = "split.mp3"
    prompt = "假设你是一个英语老师，你需要针对我给你的文章进行总结并概括，用中文告诉我"
    text_summarizer.main(file_name, prompt)
