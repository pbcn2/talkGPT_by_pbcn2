
import sys
import openai
import csv
import time
import os
from AudioRecoder.audio_recorder_player import AudioRecorderPlayer
from Whisper.audio_to_text import AudioToText
from Respond.ask_for_respond import AskForRespond

api_key = "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"


def initialize(prompt):
    def save_dict_list_to_csv(dict_list, filename):
        """
        将字典列表保存为CSV文件
        dict_list: 字典列表
        filename: 文件名
        """
        with open(filename, mode='w', newline='') as f:
            fieldnames = list(dict_list[0].keys())
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for my_dict in dict_list:
                writer.writerow(my_dict)
    # 指定log文件路径
    log_path = "Respond/message.csv"
    messages = [{"role": "system", "content": prompt}]
    save_dict_list_to_csv(messages, log_path)
    ask_for_respond = AskForRespond(api_key, log_path)
    del ask_for_respond


if __name__ == "__main__":
    prompt = "hello"
    initialize(prompt)


